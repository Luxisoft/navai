<?php

if (!defined('ABSPATH')) {
    exit;
}

trait Navai_Voice_Plugin_Helpers_Trait
{
    /**
     * @param array<string, mixed> $settings
     * @return array<int, array{phase: int, key: string, label: string, enabled: bool, details: array<int, string>}>
     */
    private function build_frontend_roadmap_phases(array $settings): array
    {
        $guardrailsEnabled = !array_key_exists('enable_guardrails', $settings) || !empty($settings['enable_guardrails']);
        $approvalsEnabled = !array_key_exists('enable_approvals', $settings) || !empty($settings['enable_approvals']);
        $tracingEnabled = !array_key_exists('enable_tracing', $settings) || !empty($settings['enable_tracing']);
        $sessionMemoryEnabled = !array_key_exists('enable_session_memory', $settings) || !empty($settings['enable_session_memory']);
        $agentsEnabled = !array_key_exists('enable_agents', $settings) || !empty($settings['enable_agents']);
        $mcpEnabled = !array_key_exists('enable_mcp', $settings) || !empty($settings['enable_mcp']);
        $turnDetectionMode = $this->sanitize_realtime_turn_detection_mode($settings['realtime_turn_detection_mode'] ?? 'server_vad');
        $voiceInputMode = $this->sanitize_frontend_voice_input_mode($settings['frontend_voice_input_mode'] ?? 'vad');
        $textInputEnabled = !array_key_exists('frontend_text_input_enabled', $settings) || !empty($settings['frontend_text_input_enabled']);
        $publicFunctionsEnabled = !array_key_exists('allow_public_functions', $settings) || !empty($settings['allow_public_functions']);

        return [
            [
                'phase' => 1,
                'key' => 'guardrails',
                'label' => 'Base DB + migraciones + Guardrails (seguridad)',
                'enabled' => $guardrailsEnabled,
                'details' => [
                    'guardrails:' . ($guardrailsEnabled ? 'on' : 'off'),
                ],
            ],
            [
                'phase' => 2,
                'key' => 'approvals_traces',
                'label' => 'Aprobaciones (HITL) + Trazas basicas',
                'enabled' => $approvalsEnabled || $tracingEnabled,
                'details' => [
                    'approvals:' . ($approvalsEnabled ? 'on' : 'off'),
                    'tracing:' . ($tracingEnabled ? 'on' : 'off'),
                ],
            ],
            [
                'phase' => 3,
                'key' => 'sessions_memory_history',
                'label' => 'Sesiones + memoria + transcript/historial',
                'enabled' => $sessionMemoryEnabled,
                'details' => [
                    'session_memory:' . ($sessionMemoryEnabled ? 'on' : 'off'),
                ],
            ],
            [
                'phase' => 4,
                'key' => 'voice_ux_realtime',
                'label' => 'UX de voz avanzada (realtime) + modo texto/voz',
                'enabled' => true,
                'details' => [
                    'voice_input:' . $voiceInputMode,
                    'text_input:' . ($textInputEnabled ? 'on' : 'off'),
                    'turn_detection:' . $turnDetectionMode,
                ],
            ],
            [
                'phase' => 5,
                'key' => 'js_functions',
                'label' => 'Funciones JS robustas (schema, timeout, test)',
                'enabled' => true,
                'details' => [
                    'public_functions:' . ($publicFunctionsEnabled ? 'on' : 'off'),
                ],
            ],
            [
                'phase' => 6,
                'key' => 'multiagent_handoffs',
                'label' => 'Multiagente + handoffs',
                'enabled' => $agentsEnabled,
                'details' => [
                    'agents:' . ($agentsEnabled ? 'on' : 'off'),
                ],
            ],
            [
                'phase' => 7,
                'key' => 'mcp_integrations',
                'label' => 'MCP + integraciones estandar',
                'enabled' => $mcpEnabled,
                'details' => [
                    'mcp:' . ($mcpEnabled ? 'on' : 'off'),
                ],
            ],
        ];
    }

    private function resolve_public_routes(): array
    {
        $settings = $this->settings->get_settings();
        $baseRoutes = $this->settings->get_allowed_routes_for_current_user();

        /** @var mixed $raw */
        $raw = apply_filters('navai_voice_routes', $baseRoutes, $settings);
        if (!is_array($raw)) {
            $raw = $baseRoutes;
        }

        $routes = [];
        $seenKeys = [];
        foreach ($raw as $item) {
            if (!is_array($item)) {
                continue;
            }

            $name = isset($item['name']) ? sanitize_text_field((string) $item['name']) : '';
            $description = isset($item['description'])
                ? sanitize_text_field((string) $item['description'])
                : 'Allowed route.';
            $path = isset($item['path']) ? trim((string) $item['path']) : '';

            if ($name === '' || $path === '') {
                continue;
            }

            if (str_starts_with($path, '/')) {
                $path = home_url($path);
            }

            $path = esc_url_raw($path);
            if (!$this->is_navigable_url($path)) {
                continue;
            }

            $dedupeKey = strtolower($name) . '|' . strtolower(untrailingslashit($path));
            if (isset($seenKeys[$dedupeKey])) {
                continue;
            }
            $seenKeys[$dedupeKey] = true;

            $synonyms = [];
            if (isset($item['synonyms']) && is_array($item['synonyms'])) {
                foreach ($item['synonyms'] as $synonym) {
                    if (!is_string($synonym)) {
                        continue;
                    }

                    $clean = sanitize_text_field($synonym);
                    if ($clean !== '') {
                        $synonyms[] = $clean;
                    }
                }
            }
            $synonyms = array_merge($synonyms, $this->build_route_synonyms($name, $path));

            $routes[] = [
                'name' => $name,
                'path' => $path,
                'description' => $description,
                'synonyms' => array_values(array_unique($synonyms)),
            ];
        }

        return $routes;
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<int, array{name: string, path: string, description: string, synonyms: array<int, string>}>
     */
    private function get_menu_routes_from_settings(array $settings): array
    {
        if (!function_exists('wp_get_nav_menus') || !function_exists('wp_get_nav_menu_items')) {
            return [];
        }

        $selectedIds = $this->get_selected_menu_item_ids($settings);
        $routesById = $this->get_menu_routes_index();

        if (count($selectedIds) === 0) {
            return [];
        }

        $selectedRoutes = [];
        foreach ($selectedIds as $id) {
            if (isset($routesById[$id])) {
                $selectedRoutes[] = $routesById[$id];
            }
        }

        return $selectedRoutes;
    }

    /**
     * @param mixed $item
     * @return array{name: string, path: string, description: string, synonyms: array<int, string>}|null
     */
    private function build_route_from_menu_item($item): ?array
    {
        if (!is_object($item) || !isset($item->url, $item->title)) {
            return null;
        }

        $url = esc_url_raw((string) $item->url);
        if (!$this->is_navigable_url($url)) {
            return null;
        }

        $title = trim(wp_strip_all_tags((string) $item->title));
        if ($title === '') {
            return null;
        }

        if (str_starts_with($url, '/')) {
            $url = home_url($url);
        }

        return [
            'name' => $title,
            'path' => $url,
            'description' => __('Ruta de menu seleccionada en WordPress.', 'navai-voice'),
            'synonyms' => $this->build_route_synonyms($title, $url),
        ];
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<int, int>
     */
    private function get_selected_menu_item_ids(array $settings): array
    {
        $idsRaw = is_array($settings['allowed_menu_item_ids'] ?? null)
            ? $settings['allowed_menu_item_ids']
            : [];

        $ids = array_map('absint', $idsRaw);
        return array_values(array_filter(array_unique($ids), static fn(int $id): bool => $id > 0));
    }

    /**
     * @return array<int, array{name: string, path: string, description: string, synonyms: array<int, string>}>
     */
    private function get_menu_routes_index(): array
    {
        $menus = wp_get_nav_menus();
        if (!is_array($menus) || count($menus) === 0) {
            return [];
        }

        $routesById = [];
        foreach ($menus as $menu) {
            if (!isset($menu->term_id)) {
                continue;
            }

            $items = wp_get_nav_menu_items((int) $menu->term_id, ['update_post_term_cache' => false]);
            if (!is_array($items)) {
                continue;
            }

            foreach ($items as $item) {
                if (!is_object($item) || !isset($item->ID)) {
                    continue;
                }

                $itemId = absint((int) $item->ID);
                if ($itemId <= 0) {
                    continue;
                }

                $route = $this->build_route_from_menu_item($item);
                if (!is_array($route)) {
                    continue;
                }

                $routesById[$itemId] = $route;
            }
        }

        return $routesById;
    }

    private function is_navigable_url(string $url): bool
    {
        $value = trim($url);
        if ($value === '' || $value === '#') {
            return false;
        }

        $normalized = strtolower($value);
        if (str_starts_with($normalized, 'javascript:')) {
            return false;
        }

        return true;
    }

    /**
     * @return array<int, string>
     */
    private function build_route_synonyms(string $name, string $path): array
    {
        $synonyms = [];

        $cleanName = sanitize_text_field($name);
        if ($cleanName !== '') {
            $synonyms[] = strtolower($cleanName);
        }

        foreach ($this->extract_path_segments($path) as $segment) {
            $synonyms[] = strtolower($segment);
        }

        return array_values(array_unique(array_filter($synonyms, static fn(string $value): bool => $value !== '')));
    }

    /**
     * @return array<int, string>
     */
    private function extract_path_segments(string $path): array
    {
        $segments = [];

        $relativePath = wp_parse_url($path, PHP_URL_PATH);
        if (!is_string($relativePath) || trim($relativePath) === '') {
            return $segments;
        }

        $parts = explode('/', trim($relativePath, '/'));
        foreach ($parts as $part) {
            $token = sanitize_title($part);
            if ($token !== '') {
                $segments[] = str_replace('-', ' ', $token);
            }
        }

        return array_values(array_unique($segments));
    }

    /**
     * @param mixed $value
     */
    private function to_bool($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        $normalized = strtolower(trim((string) $value));
        return in_array($normalized, ['1', 'true', 'yes', 'on'], true);
    }

    /**
     * @param mixed $value
     */
    private function sanitize_frontend_voice_input_mode($value): string
    {
        $mode = sanitize_key((string) $value);
        if (!in_array($mode, ['vad', 'ptt'], true)) {
            return 'vad';
        }

        return $mode;
    }

    /**
     * @param mixed $value
     */
    private function sanitize_realtime_turn_detection_mode($value): string
    {
        $mode = sanitize_key((string) $value);
        if (!in_array($mode, ['server_vad', 'semantic_vad', 'none'], true)) {
            return 'server_vad';
        }

        return $mode;
    }

    /**
     * @param mixed $value
     */
    private function sanitize_int_range_value($value, int $fallback, int $min, int $max): int
    {
        $number = is_numeric($value) ? (int) $value : $fallback;
        if ($number < $min || $number > $max) {
            return $fallback;
        }

        return $number;
    }

    /**
     * @param mixed $value
     */
    private function sanitize_float_range_value($value, float $fallback, float $min, float $max, int $precision = 2): float
    {
        $number = is_numeric($value) ? (float) $value : $fallback;
        if (!is_finite($number) || $number < $min || $number > $max) {
            $number = $fallback;
        }

        return round($number, $precision);
    }

    /**
     * @param array<string, mixed> $settings
     */
    private function resolve_frontend_display_mode(array $settings): string
    {
        $mode = isset($settings['frontend_display_mode']) ? sanitize_key((string) $settings['frontend_display_mode']) : '';
        if (!in_array($mode, ['global', 'shortcode'], true)) {
            return 'global';
        }

        return $mode;
    }

    /**
     * @param array<string, mixed> $settings
     */
    private function resolve_frontend_button_side(array $settings): string
    {
        $side = isset($settings['frontend_button_side']) ? sanitize_key((string) $settings['frontend_button_side']) : '';
        if (!in_array($side, ['left', 'right'], true)) {
            return 'left';
        }

        return $side;
    }

    /**
     * @param array<string, mixed> $settings
     */
    private function resolve_frontend_button_color(array $settings, string $key, string $fallback): string
    {
        $sanitizedFallback = sanitize_hex_color($fallback);
        if (!is_string($sanitizedFallback) || trim($sanitizedFallback) === '') {
            $sanitizedFallback = '#1263dc';
        }

        $raw = isset($settings[$key]) ? (string) $settings[$key] : '';
        $color = sanitize_hex_color($raw);
        if (!is_string($color) || trim($color) === '') {
            return $sanitizedFallback;
        }

        return $color;
    }

    /**
     * @param array<string, mixed> $settings
     */
    private function resolve_frontend_show_button_text(array $settings): bool
    {
        if (!array_key_exists('frontend_show_button_text', $settings)) {
            return true;
        }

        return $this->to_bool($settings['frontend_show_button_text']);
    }

    /**
     * @param array<string, mixed> $settings
     */
    private function resolve_frontend_button_text(array $settings, string $key, string $fallback): string
    {
        $sanitizedFallback = sanitize_text_field($fallback);
        if (trim($sanitizedFallback) === '') {
            $sanitizedFallback = 'NAVAI';
        }

        $value = sanitize_text_field((string) ($settings[$key] ?? ''));
        if (trim($value) === '') {
            return $sanitizedFallback;
        }

        return $value;
    }

    /**
     * @param array<string, mixed> $settings
     */
    private function can_render_widget_for_current_user(array $settings): bool
    {
        $allowedRoles = $this->normalize_allowed_frontend_roles($settings['frontend_allowed_roles'] ?? []);
        if (count($allowedRoles) === 0) {
            return false;
        }

        if (!is_user_logged_in()) {
            return in_array('guest', $allowedRoles, true);
        }

        $user = wp_get_current_user();
        if (!($user instanceof WP_User)) {
            return false;
        }

        if (!is_array($user->roles)) {
            return false;
        }

        foreach ($user->roles as $role) {
            $roleKey = sanitize_key((string) $role);
            if ($roleKey !== '' && in_array($roleKey, $allowedRoles, true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * In wp-admin, always allow administrators to use the global widget.
     *
     * @param array<string, mixed> $settings
     */
    private function can_render_global_widget_for_current_context(array $settings): bool
    {
        if (is_admin() && current_user_can('manage_options')) {
            return true;
        }

        return $this->can_render_widget_for_current_user($settings);
    }

    /**
     * @param mixed $value
     * @return array<int, string>
     */
    private function normalize_allowed_frontend_roles($value): array
    {
        if (!is_array($value)) {
            return [];
        }

        $roles = [];
        foreach ($value as $item) {
            $role = sanitize_key((string) $item);
            if ($role !== '') {
                $roles[] = $role;
            }
        }

        return array_values(array_unique($roles));
    }

    /**
     * @param array<string, mixed> $attributes
     * @param array<string, mixed> $options
     */
    private function render_widget_markup(array $attributes, array $options): string
    {
        $startLabel = is_string($attributes['label'] ?? null) ? (string) $attributes['label'] : __('Start Voice', 'navai-voice');
        $stopLabel = is_string($attributes['stop_label'] ?? null) ? (string) $attributes['stop_label'] : __('Stop Voice', 'navai-voice');
        $debug = $this->to_bool($attributes['debug'] ?? '0');

        $floating = !empty($options['floating']);
        $persistActive = !empty($options['persist_active']);
        $showStatus = array_key_exists('show_status', $options) ? !empty($options['show_status']) : true;
        $widgetMode = isset($options['widget_mode']) ? sanitize_key((string) $options['widget_mode']) : 'shortcode';
        if (!in_array($widgetMode, ['global', 'shortcode'], true)) {
            $widgetMode = 'shortcode';
        }
        $buttonSide = isset($options['button_side']) ? sanitize_key((string) $options['button_side']) : 'left';
        if (!in_array($buttonSide, ['left', 'right'], true)) {
            $buttonSide = 'left';
        }
        $buttonColorIdle = isset($options['button_color_idle']) ? sanitize_hex_color((string) $options['button_color_idle']) : null;
        if (!is_string($buttonColorIdle) || trim($buttonColorIdle) === '') {
            $buttonColorIdle = '#1263dc';
        }
        $buttonColorActive = isset($options['button_color_active']) ? sanitize_hex_color((string) $options['button_color_active']) : null;
        if (!is_string($buttonColorActive) || trim($buttonColorActive) === '') {
            $buttonColorActive = '#10883f';
        }
        $showButtonText = array_key_exists('show_button_text', $options) ? !empty($options['show_button_text']) : true;
        $voiceInputMode = isset($options['voice_input_mode'])
            ? $this->sanitize_frontend_voice_input_mode((string) $options['voice_input_mode'])
            : 'vad';
        $textInputEnabled = array_key_exists('text_input_enabled', $options) ? !empty($options['text_input_enabled']) : true;
        $autoInitialize = array_key_exists('auto_initialize', $options) ? !empty($options['auto_initialize']) : false;
        $assistantStopToolEnabled = array_key_exists('assistant_stop_tool_enabled', $options)
            ? !empty($options['assistant_stop_tool_enabled'])
            : true;
        $textPlaceholder = isset($options['text_placeholder'])
            ? sanitize_text_field((string) $options['text_placeholder'])
            : __('Escribe un mensaje...', 'navai-voice');
        if (trim($textPlaceholder) === '') {
            $textPlaceholder = __('Escribe un mensaje...', 'navai-voice');
        }
        $widgetInlineStyle = '--navai-btn-idle-color:' . $buttonColorIdle . ';--navai-btn-connected-color:' . $buttonColorActive . ';';

        $widgetClass = 'navai-voice-widget';
        if ($floating) {
            $widgetClass .= ' navai-voice-widget--floating';
            $widgetClass .= $buttonSide === 'right'
                ? ' navai-voice-widget--side-right'
                : ' navai-voice-widget--side-left';
        }

        if (is_string($attributes['class'] ?? null) && trim((string) $attributes['class']) !== '') {
            $extra = array_filter(
                array_map(
                    'sanitize_html_class',
                    preg_split('/\s+/', trim((string) $attributes['class'])) ?: []
                )
            );
            if (!empty($extra)) {
                $widgetClass .= ' ' . implode(' ', $extra);
            }
        }

        $data = [
            'start-label' => $startLabel,
            'stop-label' => $stopLabel,
            'model' => is_string($attributes['model'] ?? null) ? (string) $attributes['model'] : '',
            'voice' => is_string($attributes['voice'] ?? null) ? (string) $attributes['voice'] : '',
            'instructions' => is_string($attributes['instructions'] ?? null) ? (string) $attributes['instructions'] : '',
            'language' => is_string($attributes['language'] ?? null) ? (string) $attributes['language'] : '',
            'voice-accent' => is_string($attributes['voice_accent'] ?? null) ? (string) $attributes['voice_accent'] : '',
            'voice-tone' => is_string($attributes['voice_tone'] ?? null) ? (string) $attributes['voice_tone'] : '',
            'debug' => $debug ? '1' : '0',
            'widget-mode' => $widgetMode,
            'floating' => $floating ? '1' : '0',
            'button-side' => $buttonSide,
            'persist-active' => $persistActive ? '1' : '0',
            'show-text' => $showButtonText ? '1' : '0',
            'voice-input-mode' => $voiceInputMode,
            'text-enabled' => $textInputEnabled ? '1' : '0',
            'auto-initialize' => $autoInitialize ? '1' : '0',
            'assistant-stop-tool-enabled' => $assistantStopToolEnabled ? '1' : '0',
            'text-placeholder' => $textPlaceholder,
        ];

        ob_start();
        ?>
        <div class="<?php echo esc_attr($widgetClass); ?>" style="<?php echo esc_attr($widgetInlineStyle); ?>"
            <?php foreach ($data as $key => $value) : ?>
                <?php printf(' data-%s="%s"', esc_attr($key), esc_attr($value)); ?>
            <?php endforeach; ?>
        >
            <button type="button" class="navai-voice-toggle" aria-pressed="false" aria-label="<?php echo esc_attr($startLabel); ?>">
                <span class="navai-voice-toggle-icon dashicons dashicons-microphone" aria-hidden="true"></span>
                <span class="navai-voice-toggle-text"><?php echo esc_html($startLabel); ?></span>
            </button>
            <?php if ($voiceInputMode === 'ptt') : ?>
                <button
                    type="button"
                    class="navai-voice-ptt"
                    aria-label="<?php echo esc_attr__('Push to talk', 'navai-voice'); ?>"
                    disabled
                >
                    <span class="dashicons dashicons-controls-volumeon" aria-hidden="true"></span>
                    <span class="navai-voice-ptt-text"><?php echo esc_html__('Mantener para hablar', 'navai-voice'); ?></span>
                </button>
            <?php endif; ?>
            <?php if ($textInputEnabled) : ?>
                <?php $textInputId = 'navai-voice-text-' . wp_generate_uuid4(); ?>
                <form class="navai-voice-text-form" novalidate>
                    <label class="screen-reader-text" for="<?php echo esc_attr($textInputId); ?>">
                        <?php echo esc_html__('Mensaje de texto', 'navai-voice'); ?>
                    </label>
                    <input
                        id="<?php echo esc_attr($textInputId); ?>"
                        type="text"
                        class="navai-voice-text-input"
                        placeholder="<?php echo esc_attr($textPlaceholder); ?>"
                        autocomplete="off"
                    />
                    <button type="submit" class="navai-voice-text-send">
                        <?php echo esc_html__('Enviar', 'navai-voice'); ?>
                    </button>
                </form>
            <?php endif; ?>
            <?php if ($showStatus) : ?>
                <p class="navai-voice-status" aria-live="polite"><?php echo esc_html__('Idle', 'navai-voice'); ?></p>
            <?php endif; ?>
            <?php if ($debug) : ?>
                <div class="navai-voice-log-toolbar" role="group" aria-label="<?php echo esc_attr__('Controles de log', 'navai-voice'); ?>">
                    <button type="button" class="navai-voice-log-copy button button-small">
                        <?php echo esc_html__('Copiar log', 'navai-voice'); ?>
                    </button>
                    <div class="navai-voice-log-filters" role="group" aria-label="<?php echo esc_attr__('Filtros de log', 'navai-voice'); ?>">
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="agent_response" checked />
                            <span><?php echo esc_html__('Respuesta IA', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="function_response" checked />
                            <span><?php echo esc_html__('Respuesta funciones', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="functions_loaded" checked />
                            <span><?php echo esc_html__('Funciones cargadas', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="routes_loaded" checked />
                            <span><?php echo esc_html__('Rutas cargadas', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="realtime_sent" checked />
                            <span><?php echo esc_html__('Eventos enviados', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="realtime_recv" checked />
                            <span><?php echo esc_html__('Eventos recibidos', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="connection" checked />
                            <span><?php echo esc_html__('Conexion', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="phases_loaded" checked />
                            <span><?php echo esc_html__('Fases cargadas', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="other" checked />
                            <span><?php echo esc_html__('Otros', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="warn" checked />
                            <span><?php echo esc_html__('Warnings', 'navai-voice'); ?></span>
                        </label>
                        <label class="navai-voice-log-filter-option">
                            <input type="checkbox" data-navai-log-filter="error" checked />
                            <span><?php echo esc_html__('Errores', 'navai-voice'); ?></span>
                        </label>
                    </div>
                </div>
            <?php endif; ?>
            <pre class="navai-voice-log" <?php echo $debug ? '' : 'hidden'; ?>></pre>
        </div>
        <?php

        return (string) ob_get_clean();
    }

    private function resolve_admin_icon_url(): string
    {
        $transparentPath = NAVAI_VOICE_PATH . 'assets/img/icon_navai_transparent.png';
        if (file_exists($transparentPath)) {
            return NAVAI_VOICE_URL . 'assets/img/icon_navai_transparent.png';
        }

        return NAVAI_VOICE_URL . 'assets/img/icon_navai.jpg';
    }
}
